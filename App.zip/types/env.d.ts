declare module '@env' {
  export const REACT_APP_BACKEND_URL: string;
  export const GOOGLE_API_KEY: string;
}

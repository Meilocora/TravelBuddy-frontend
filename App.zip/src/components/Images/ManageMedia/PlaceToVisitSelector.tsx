import React, { ReactElement, useContext, useEffect, useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';

import { GlobalStyles } from '../../../constants/styles';
import { Icons, PlaceToVisit } from '../../../models';
import Input from '../../UI/form/Input';
import { PlaceContext } from '../../../store/place-context';
import PlaceToVisitSelectorList from './PlaceToVisitSelectorList';
import IconButton from '../../UI/IconButton';
import { UserContext } from '../../../store/user-context';
import { LatLng } from 'react-native-maps';

interface PlaceToVisitSelectorProps {
  onChangePlace: (placeId: number | undefined) => void;
  invalid: boolean;
  defaultValue: number | undefined;
  errors: string[];
  mediumCoords?: LatLng;
  autoSuggestion?: boolean;
}

const PlaceToVisitSelector: React.FC<PlaceToVisitSelectorProps> = ({
  onChangePlace,
  invalid,
  defaultValue,
  errors,
  mediumCoords,
  autoSuggestion = true,
}): ReactElement => {
  const [openSelection, setOpenSelection] = useState(false);
  const [autoSuggestEnabled, setAutoSuggestEnabled] = useState(autoSuggestion);

  const placesCtx = useContext(PlaceContext);
  const userCtx = useContext(UserContext);

  let place: PlaceToVisit | undefined;
  let places = placesCtx.placesToVisit;
  if (defaultValue) {
    place = places.find((p) => p.id === defaultValue);
  }

  useEffect(() => {
    if (!defaultValue && autoSuggestEnabled) {
      let suggestedPlace: PlaceToVisit | undefined;

      if (
        mediumCoords &&
        mediumCoords['latitude'] !== 0 &&
        mediumCoords['longitude'] !== 0
      ) {
        suggestedPlace = placesCtx.findNearestPlace(mediumCoords);
      } else if (userCtx.currentLocation) {
        suggestedPlace = placesCtx.findNearestPlace(userCtx.currentLocation);
      }

      if (suggestedPlace) {
        onChangePlace(suggestedPlace.id);
      }
    }
  }, [defaultValue, autoSuggestEnabled, mediumCoords, userCtx.currentLocation]);

  function handleOpenModal() {
    setOpenSelection(true);
  }

  function handleClearPlace() {
    setAutoSuggestEnabled(false);
    onChangePlace(undefined);
  }

  return (
    <>
      <PlaceToVisitSelectorList
        visible={openSelection}
        defaultValue={place || ''}
        onCancel={() => setOpenSelection(false)}
        onChangePlace={onChangePlace}
      />
      <View style={styles.container}>
        <View>
          <Pressable onPress={handleOpenModal}>
            <Input
              maxLength={12}
              label='Place'
              errors={errors}
              textInputConfig={{
                value: place?.name,
                readOnly: true,
                textAlign: 'left',
              }}
            />
          </Pressable>
          {defaultValue && (
            <IconButton
              icon={Icons.delete}
              onPress={handleClearPlace}
              style={styles.deleteButton}
              color={GlobalStyles.colors.graySoft}
            />
          )}
        </View>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  outside: {
    flex: 1,
    height: '100%',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
  },
  deleteButton: {
    position: 'absolute',
    right: -4,
    bottom: 10,
  },
});

export default PlaceToVisitSelector;

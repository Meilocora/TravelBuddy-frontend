export const DELTA = 0.005;

export const EDGE_PADDING = { top: 60, right: 60, bottom: 60, left: 60 };
